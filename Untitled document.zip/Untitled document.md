﻿**linux\_40\_Command** 

**Q1.How to make a directory.**

Command definition in single line:

Example: mkdir command is use for create directory

Command:

Syntax:'mkdir directory\_name'

`   `mkdir pushpa

Describe the command:

Example:

mkdir: It is used to create a directory

![](Aspose.Words.c2cb4744-eb71-4a13-86c2-0d6c148b0d0b.001.png)

yogesh@Yogesh-Ubuntu:~$ mkdir pushpa

yogesh@Yogesh-Ubuntu:~$ ls

Desktop    Downloads   mkdir1  Pictures  pushpa  Templates  wget-log   yogesh

Documents  latest.zip  Music   Public    snap    Videos     wordpress


**Q2. How to Remove a directory.**

To remove a directory in Linux, you can use the rmdir or rm command. However, these commands have some differences in their functionality:

Using rmdir:

Command definition in single line:

Example: The rmdir command is specifically used to remove directories.

Command:

Syntax: rmdir 'directory\_name'

rmdir pushpa

Describe the command:

Example:

rmdir: The rmdir command is specifically used to remove empty directories.

![](Aspose.Words.c2cb4744-eb71-4a13-86c2-0d6c148b0d0b.002.png)

yogesh@Yogesh-Ubuntu:~$ rmdir pushpa

yogesh@Yogesh-Ubuntu:~$ ls

Desktop    Downloads   mkdir1  Pictures  snap       Videos    wordpress

Documents  latest.zip  Music   Public    Templates  wget-log  yogesh



Using rm:

The rm command, when used with the -r or -rf option, can be used to delete directories recursively, along with their contents.

Syntax to remove a directory: rm -d directory\_name

` `rm -d pushpa  

![](Aspose.Words.c2cb4744-eb71-4a13-86c2-0d6c148b0d0b.003.png)

yogesh@Yogesh-Ubuntu:~$ rm -d pushpa

yogesh@Yogesh-Ubuntu:~$ ls

Desktop    Downloads   mkdir1  Pictures  snap       Videos    wordpress

Documents  latest.zip  Music   Public    Templates  wget-log  yogesh


Syntax to remove a directory and its contents recursively (use with caution, as it deletes files and subdirectories inside the specified directory):

rm -r directory\_name

`  `rm -r pushpa

![](Aspose.Words.c2cb4744-eb71-4a13-86c2-0d6c148b0d0b.004.png)

yogesh@Yogesh-Ubuntu:~$ rm -r pushpa

yogesh@Yogesh-Ubuntu:~$ ls

Desktop    Downloads   mkdir1  Pictures  snap       Videos    wordpress

Documents  latest.zip  Music   Public    Templates  wget-log  yogesh



Syntax to forcefully remove a directory and its contents without prompting for confirmation:

rm -rf directory\_name

`  `rm -rf demo

![](Aspose.Words.c2cb4744-eb71-4a13-86c2-0d6c148b0d0b.005.png)

yogesh@Yogesh-Ubuntu:~$ rm -rf pushpa

yogesh@Yogesh-Ubuntu:~$ ls

Desktop    Downloads   mkdir1  Pictures  snap       Videos    wordpress

Documents  latest.zip  Music   Public    Templates  wget-log  yogesh



Note of Caution: Be extremely cautious while using  rm,-rfas it will forcefully delete the specified directory and its contents without asking for confirmation

**Q3. Make a copy of a file.**

To make a copy of a file in Linux, you can use the cp command. The basic syntax for copying a file is:

Syntax:

cp source\_file\_name destination\_file\_name

`   `cp data.txt data1.txt

Image

Replace source\_file with the file you want to copy and destination\_file with the name or path where you want to create the copy.

For example, to copy a file named original.txt to create a copy named copy\_of\_original.txt in the same directory:

**Q4. Move or rename a file.**

To move or rename a file in Linux, you can use the mv command, which is capable of performing both renaming and moving files or directories.

Renaming a File:

To rename a file, use mv followed by the current filename and the desired new filename:

Syntax:

mv current\_file\_name new\_file\_name

` `mv data.txt newdata.txt 

image

**Q5. Create an empty file.**

The touch command is often used to create empty files or update timestamps of existing files. If the file does not exist, touch will create an empty file.

Syntax:

touch filename.ext

touch empty\_file.txt

image

For example: To create an empty file named empty\_file.txt.

**Q5. Remove multiple files with a single command.**

To remove multiple files with a single command in Linux, you can use the rm (remove) command followed by the names of the files you want to delete.

You can specify the names of the files you want to remove:

Syntax:

rm file1.txt file2.txt file3.txt

` `rm data1.txt empty\_file.txt newdata.txt

image

Removing Files Interactively:

You can use the -i flag with rm to prompt for confirmation before deleting each file:

Syntax:

rm -i file1\_name file2\_name file3\_name

rm -i file.txt file2.txt emptly.txt

image

This command will prompt for confirmation before deleting each file individually.

Using Wildcards (\*):

You can also use wildcards to match multiple files based on a pattern:

Remove Files with a Common Pattern:

For instance, to remove all files with the .txt extension in the current directory:

rm \*.txt

rm \*.txt

image

**Q6. Remove content from the folder without removing folder.**

To remove all files and subdirectories within a folder without deleting the folder itself, you can use the rm command with the -r (recursive) option, targeting only the contents of the directory, not the directory itself.

Syntax:

rm -r /path/to/directory/\*

rm -r pushpa/\*

image

image

Replace /path/to/directory with the actual path to the directory whose contents you want to remove.

**Q7. Create multiple folder(a-z) with a single command.**

example command using brace expansion and the mkdir command to create folders from a to z:

Syntax:

mkdir {a..z}

mkdir {a..z}

image

Executing this command will create directories with the names a, b, c, ..., z in the current working directory. Each directory will be named after a letter from a to z.







